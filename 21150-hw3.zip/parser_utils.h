#ifndef __PARSER_UTILS_H
#define __PARSER_UTILS_H


typedef enum { NUM, STRING, OTHER } ExprType;


typedef struct ExprNode {
	ExprType exprType;
	double numValue;
	char * stringValue;
} ExprNode;

typedef struct myNode {
    char* name;
    struct myNode * next;
} myNode;





ExprNode makeWithPlus(ExprNode a , ExprNode b );
ExprNode makeWithStar(ExprNode a, ExprNode b);
ExprNode makeWithMinus(ExprNode a, ExprNode b);

ExprNode makeString(char * str);
ExprNode makeNUM(double nmbr);
ExprNode makeOther();

myNode * emptyList ();
void push(struct myNode* head, char* name);
void search(struct myNode* head, char* searched);

#endif
