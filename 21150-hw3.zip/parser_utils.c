#include "parser_utils.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>








 char * concat(const char *s1, const char *s2) {
    const size_t len1 = strlen(s1);
    const size_t len2 = strlen(s2);
    char *result = malloc(len1+len2+1);//+1 for the null-terminator
    //in real code you would check for errors in malloc here
        memcpy(result, s1, len1);
         memcpy(result+len1, s2, len2+1);//+1 to copy the null-terminator
     return result;
}

ExprNode makeOther() {
       ExprNode result; // = malloc(sizeof (ExprNode))
        result.exprType = OTHER;
        return result;
}

ExprNode  makeString(char * str) {
     //  ExprNode result; // = malloc(sizeof (ExprNode));
	 ExprNode result;
        result.exprType = STRING;
		result.stringValue = str;
        return result;
}

ExprNode makeNUM(double nmbr) {
      ExprNode result; // = malloc(sizeof (ExprNode));
		
        result.exprType = NUM;		
		result.numValue = nmbr;
        return result;
}

ExprNode makeWithPlus(ExprNode left, ExprNode right) {
    // ExprNode result; 

	if( left.exprType == NUM && right.exprType == NUM){
       double numValue = left.numValue + right.numValue;
	   printf( "%f + %f => %f\n", left.numValue, right.numValue, numValue );
       return makeNUM(numValue); 
	}
	else if (left.exprType == STRING && right.exprType == STRING ){
	printf("%s",left.stringValue); 
	char * stringValue = concat ( left.stringValue, right.stringValue);
	 printf( "%s + %s => %s\n", left.stringValue, right.stringValue, stringValue );
	 return makeString(stringValue);
	}
	else {}

}

ExprNode makeWithMinus(ExprNode left, ExprNode right) {
         
if( left.exprType == NUM && right.exprType == NUM){
	double numValue = left.numValue - right.numValue;
		 printf( "%f - %f => %f\n", left.numValue, right.numValue, numValue );
	return makeNUM(numValue); }
else {
return makeOther();
}
}

ExprNode makeWithStar(ExprNode left, ExprNode right) {
         
if( left.exprType == NUM && right.exprType == NUM){
		double numValue = left.numValue * right.numValue;
		 printf( "%f * %f => %f\n", left.numValue, right.numValue, numValue );
        return makeNUM(numValue); }
else {
makeOther();
}
}

myNode * emptyList () {
struct myNode* head = malloc(sizeof(myNode));
  head->name = "Dummy";
  head->next = NULL;
  return head;
}

void push(struct myNode* head, char* name)
{
    struct myNode* ptr = malloc(sizeof(myNode));
    ptr->next = head->next;
    ptr->name = name;
    head->next = ptr;
}


void search(struct myNode* head, char* searched) {
int check= 0;
    struct myNode* current = head;  // Initialize current
    while (current != NULL)
    {
        if (strcmp(current->name,searched)==0)
        {
            check = 1; 
	}
	current = current -> next;
if (check) {
}
else {
printf("ERROR: The function (%s) is not declared before \n",searched);
}
}	    	
}
